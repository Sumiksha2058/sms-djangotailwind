import { eq, and, like, gte, lte, desc, asc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  students,
  teachers,
  courses,
  subjects,
  attendance,
  assignments,
  results,
  exams,
  timetables,
  studentFees,
  payments,
  parents,
  courseSubjects,
  teacherSubjects,
  assignmentSubmissions,
  feeStructures,
  notifications,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============================================================================
// USER MANAGEMENT QUERIES
// ============================================================================

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "phone", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllUsers(role?: string) {
  const db = await getDb();
  if (!db) return [];

  if (role) {
    return await db.select().from(users).where(eq(users.role, role as any));
  }
  return await db.select().from(users);
}

// ============================================================================
// STUDENT QUERIES
// ============================================================================

export async function createStudent(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(students).values(data);
  return result;
}

export async function getStudentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(students).where(eq(students.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getStudentByUserId(userId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(students)
    .where(eq(students.userId, userId))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getStudentsByCourse(courseId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(students).where(eq(students.courseId, courseId));
}

export async function getAllStudents(status?: string) {
  const db = await getDb();
  if (!db) return [];

  if (status) {
    return await db.select().from(students).where(eq(students.status, status as any));
  }
  return await db.select().from(students);
}

export async function updateStudent(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(students).set(data).where(eq(students.id, id));
}

export async function searchStudents(query: string) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(students)
    .where(
      or(
        like(students.studentId, `%${query}%`),
        like(students.rollNumber, `%${query}%`)
      )
    );
}

// ============================================================================
// TEACHER QUERIES
// ============================================================================

export async function createTeacher(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(teachers).values(data);
}

export async function getTeacherById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(teachers).where(eq(teachers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getTeacherByUserId(userId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(teachers)
    .where(eq(teachers.userId, userId))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllTeachers() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(teachers);
}

export async function updateTeacher(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(teachers).set(data).where(eq(teachers.id, id));
}

// ============================================================================
// COURSE QUERIES
// ============================================================================

export async function createCourse(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(courses).values(data);
}

export async function getCourseById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(courses).where(eq(courses.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllCourses() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(courses);
}

export async function updateCourse(id: number, data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.update(courses).set(data).where(eq(courses.id, id));
}

// ============================================================================
// SUBJECT QUERIES
// ============================================================================

export async function createSubject(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(subjects).values(data);
}

export async function getSubjectById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(subjects).where(eq(subjects.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllSubjects() {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(subjects);
}

// ============================================================================
// ATTENDANCE QUERIES
// ============================================================================

export async function markAttendance(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(attendance).values(data);
}

export async function getAttendanceByStudent(studentId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(attendance)
    .where(eq(attendance.studentId, studentId))
    .orderBy(desc(attendance.attendanceDate));
}

export async function getAttendanceByDate(date: Date) {
  const db = await getDb();
  if (!db) return [];

  const startOfDay = new Date(date);
  startOfDay.setHours(0, 0, 0, 0);
  const endOfDay = new Date(date);
  endOfDay.setHours(23, 59, 59, 999);

  return await db
    .select()
    .from(attendance)
    .where(
      and(
        gte(attendance.attendanceDate, startOfDay),
        lte(attendance.attendanceDate, endOfDay)
      )
    );
}

export async function calculateAttendancePercentage(studentId: number, subjectId: number) {
  const db = await getDb();
  if (!db) return 0;

  const records = await db
    .select()
    .from(attendance)
    .where(
      and(
        eq(attendance.studentId, studentId),
        eq(attendance.subjectId, subjectId)
      )
    );

  if (records.length === 0) return 0;

  const presentCount = records.filter((r) => r.status === "present").length;
  return Math.round((presentCount / records.length) * 100);
}

// ============================================================================
// ASSIGNMENT QUERIES
// ============================================================================

export async function createAssignment(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(assignments).values(data);
}

export async function getAssignmentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(assignments)
    .where(eq(assignments.id, id))
    .limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAssignmentsBySubject(subjectId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(assignments)
    .where(eq(assignments.subjectId, subjectId))
    .orderBy(desc(assignments.dueDate));
}

// ============================================================================
// EXAM QUERIES
// ============================================================================

export async function createExam(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(exams).values(data);
}

export async function getExamById(id: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db.select().from(exams).where(eq(exams.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getExamsBySubject(subjectId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(exams)
    .where(eq(exams.subjectId, subjectId))
    .orderBy(desc(exams.examDate));
}

export async function getExamsByCourse(courseId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(exams)
    .where(eq(exams.courseId, courseId))
    .orderBy(desc(exams.examDate));
}

// ============================================================================
// RESULT QUERIES
// ============================================================================

export async function createResult(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(results).values(data);
}

export async function getResultByStudent(studentId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(results)
    .where(eq(results.studentId, studentId))
    .orderBy(desc(results.createdAt));
}

export async function getResultBySubject(subjectId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(results)
    .where(eq(results.subjectId, subjectId));
}

// ============================================================================
// TIMETABLE QUERIES
// ============================================================================

export async function createTimetable(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(timetables).values(data);
}

export async function getTimetableByCourse(courseId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(timetables)
    .where(eq(timetables.courseId, courseId))
    .orderBy(asc(timetables.dayOfWeek));
}

export async function getTimetableByDay(courseId: number, day: string) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(timetables)
    .where(
      and(
        eq(timetables.courseId, courseId),
        eq(timetables.dayOfWeek, day as any)
      )
    )
    .orderBy(asc(timetables.startTime));
}

// ============================================================================
// FEE QUERIES
// ============================================================================

export async function createStudentFee(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(studentFees).values(data);
}

export async function getStudentFees(studentId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(studentFees)
    .where(eq(studentFees.studentId, studentId));
}

export async function recordPayment(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(payments).values(data);
}

export async function getPaymentsByStudent(studentId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(payments)
    .where(
      eq(payments.studentFeeId, studentId)
    )
    .orderBy(desc(payments.paymentDate));
}

// ============================================================================
// NOTIFICATION QUERIES
// ============================================================================

export async function createNotification(data: any) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(notifications).values(data);
}

export async function getUserNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt));
}

export async function markNotificationAsRead(notificationId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .update(notifications)
    .set({ isRead: true })
    .where(eq(notifications.id, notificationId));
}

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

function or(...conditions: any[]) {
  return conditions.reduce((acc, cond) => (acc ? { or: [acc, cond] } : cond));
}
