import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

// ============================================================================
// ADMIN PROCEDURE - Only for admin users
// ============================================================================

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

// ============================================================================
// STUDENT ROUTER
// ============================================================================

const studentRouter = router({
  create: adminProcedure
    .input(
      z.object({
        userId: z.number(),
        studentId: z.string(),
        rollNumber: z.string(),
        courseId: z.number(),
        dateOfBirth: z.date().optional(),
        address: z.string().optional(),
        city: z.string().optional(),
        state: z.string().optional(),
        pinCode: z.string().optional(),
        parentId: z.number().optional(),
        admissionDate: z.date().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return await db.createStudent(input);
    }),

  getById: protectedProcedure
    .input(z.number())
    .query(async ({ input }) => {
      return await db.getStudentById(input);
    }),

  getByUserId: protectedProcedure
    .input(z.number())
    .query(async ({ input, ctx }) => {
      const student = await db.getStudentByUserId(input);
      if (student && ctx.user.role !== "admin" && ctx.user.id !== input) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return student;
    }),

  getByCourse: protectedProcedure
    .input(z.number())
    .query(async ({ input }) => {
      return await db.getStudentsByCourse(input);
    }),

  getAll: protectedProcedure.query(async () => {
    return await db.getAllStudents();
  }),

  update: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        data: z.record(z.string(), z.any()),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const student = await db.getStudentById(input.id);
      if (!student) throw new TRPCError({ code: "NOT_FOUND" });

      if (ctx.user.role !== "admin" && student.userId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }

      return await db.updateStudent(input.id, input.data);
    }),

  search: protectedProcedure
    .input(z.string())
    .query(async ({ input }: { input: string }) => {
      return await db.searchStudents(input);
    }),
});

// ============================================================================
// TEACHER ROUTER
// ============================================================================

const teacherRouter = router({
  create: adminProcedure
    .input(
      z.object({
        userId: z.number(),
        employeeId: z.string(),
        qualification: z.string().optional(),
        specialization: z.string().optional(),
        joiningDate: z.date().optional(),
        department: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return await db.createTeacher(input);
    }),

  getById: protectedProcedure
    .input(z.number())
    .query(async ({ input }) => {
      return await db.getTeacherById(input);
    }),

  getByUserId: protectedProcedure
    .input(z.number())
    .query(async ({ input }: { input: number }) => {
      return await db.getTeacherByUserId(input);
    }),

  getAll: protectedProcedure.query(async () => {
    return await db.getAllTeachers();
  }) as any,

  update: adminProcedure
    .input(
      z.object({
        id: z.number(),
        data: z.record(z.string(), z.any()),
      })
    )
    .mutation(async ({ input }) => {
      return await db.updateTeacher(input.id, input.data);
    }),
});

// ============================================================================
// COURSE ROUTER
// ============================================================================

const courseRouter = router({
  create: adminProcedure
    .input(
      z.object({
        name: z.string(),
        code: z.string(),
        semester: z.number(),
        section: z.string().optional(),
        capacity: z.number().optional(),
        classTeacherId: z.number().optional(),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return await db.createCourse(input);
    }),

  getById: protectedProcedure
    .input(z.number())
    .query(async ({ input }) => {
      return await db.getCourseById(input);
    }),

  getAll: protectedProcedure.query(async () => {
    return await db.getAllCourses();
  }),

  update: adminProcedure
    .input(
      z.object({
        id: z.number(),
        data: z.record(z.string(), z.any()),
      })
    )
    .mutation(async ({ input }) => {
      return await db.updateCourse(input.id, input.data);
    }),
});

// ============================================================================
// SUBJECT ROUTER
// ============================================================================

const subjectRouter = router({
  create: adminProcedure
    .input(
      z.object({
        name: z.string(),
        code: z.string(),
        credits: z.number().optional(),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return await db.createSubject(input);
    }),

  getById: protectedProcedure
    .input(z.number())
    .query(async ({ input }) => {
      return await db.getSubjectById(input);
    }),

  getAll: protectedProcedure.query(async () => {
    return await db.getAllSubjects();
  }),
});

// ============================================================================
// ATTENDANCE ROUTER
// ============================================================================

const attendanceRouter = router({
  mark: protectedProcedure
    .input(
      z.object({
        studentId: z.number(),
        subjectId: z.number(),
        attendanceDate: z.date(),
        status: z.enum(["present", "absent", "late", "leave"]),
        remarks: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin" && ctx.user.role !== "teacher") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.markAttendance(input);
    }),

  getByStudent: protectedProcedure
    .input(z.number())
    .query(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin") {
        const student = await db.getStudentByUserId(ctx.user.id);
        if (!student || student.id !== input) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
      }
      return await db.getAttendanceByStudent(input);
    }),

  getByDate: adminProcedure
    .input(z.date())
    .query(async ({ input }) => {
      return await db.getAttendanceByDate(input);
    }),

  getPercentage: protectedProcedure
    .input(
      z.object({
        studentId: z.number(),
        subjectId: z.number(),
      })
    )
    .query(async ({ input }) => {
      return await db.calculateAttendancePercentage(input.studentId, input.subjectId);
    }),
});

// ============================================================================
// ASSIGNMENT ROUTER
// ============================================================================

const assignmentRouter = router({
  create: protectedProcedure
    .input(
      z.object({
        subjectId: z.number(),
        teacherId: z.number(),
        title: z.string(),
        description: z.string().optional(),
        dueDate: z.date(),
        totalMarks: z.number().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin" && ctx.user.role !== "teacher") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.createAssignment(input);
    }),

  getById: protectedProcedure
    .input(z.number())
    .query(async ({ input }) => {
      return await db.getAssignmentById(input);
    }),

  getBySubject: protectedProcedure
    .input(z.number())
    .query(async ({ input }) => {
      return await db.getAssignmentsBySubject(input);
    }),
});

// ============================================================================
// EXAM ROUTER
// ============================================================================

const examRouter = router({
  create: adminProcedure
    .input(
      z.object({
        subjectId: z.number(),
        courseId: z.number(),
        examName: z.string(),
        examType: z.enum(["midterm", "final", "quiz", "practical"]),
        examDate: z.date(),
        startTime: z.string().optional(),
        endTime: z.string().optional(),
        duration: z.number().optional(),
        totalMarks: z.number().optional(),
        room: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return await db.createExam(input);
    }),

  getById: protectedProcedure
    .input(z.number())
    .query(async ({ input }) => {
      return await db.getExamById(input);
    }),

  getBySubject: protectedProcedure
    .input(z.number())
    .query(async ({ input }) => {
      return await db.getExamsBySubject(input);
    }),

  getByCourse: protectedProcedure
    .input(z.number())
    .query(async ({ input }) => {
      return await db.getExamsByCourse(input);
    }),
});

// ============================================================================
// RESULT ROUTER
// ============================================================================

const resultRouter = router({
  create: protectedProcedure
    .input(
      z.object({
        studentId: z.number(),
        subjectId: z.number(),
        examId: z.number().optional(),
        marksObtained: z.number(),
        totalMarks: z.number().optional(),
        percentage: z.number().optional(),
        grade: z.string().optional(),
        remarks: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin" && ctx.user.role !== "teacher") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.createResult(input);
    }),

  getByStudent: protectedProcedure
    .input(z.number())
    .query(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin") {
        const student = await db.getStudentByUserId(ctx.user.id);
        if (!student || student.id !== input) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
      }
      return await db.getResultByStudent(input);
    }),

  getBySubject: protectedProcedure
    .input(z.number())
    .query(async ({ input }) => {
      return await db.getResultBySubject(input);
    }),
});

// ============================================================================
// TIMETABLE ROUTER
// ============================================================================

const timetableRouter = router({
  create: adminProcedure
    .input(
      z.object({
        courseId: z.number(),
        subjectId: z.number(),
        teacherId: z.number(),
        dayOfWeek: z.enum(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]),
        startTime: z.string(),
        endTime: z.string(),
        room: z.string().optional(),
        semester: z.number().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return await db.createTimetable(input);
    }),

  getByCourse: protectedProcedure
    .input(z.number())
    .query(async ({ input }) => {
      return await db.getTimetableByCourse(input);
    }),

  getByDay: protectedProcedure
    .input(
      z.object({
        courseId: z.number(),
        day: z.string(),
      })
    )
    .query(async ({ input }) => {
      return await db.getTimetableByDay(input.courseId, input.day);
    }),
});

// ============================================================================
// FEE ROUTER
// ============================================================================

const feeRouter = router({
  createStudentFee: adminProcedure
    .input(
      z.object({
        studentId: z.number(),
        feeStructureId: z.number(),
        totalAmount: z.number(),
        dueDate: z.date().optional(),
      })
    )
    .mutation(async ({ input }) => {
      return await db.createStudentFee(input);
    }),

  getByStudent: protectedProcedure
    .input(z.number())
    .query(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin") {
        const student = await db.getStudentByUserId(ctx.user.id);
        if (!student || student.id !== input) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
      }
      return await db.getStudentFees(input);
    }),

  recordPayment: protectedProcedure
    .input(
      z.object({
        studentFeeId: z.number(),
        amount: z.number(),
        paymentMethod: z.enum(["cash", "cheque", "online", "bank_transfer"]),
        transactionId: z.string().optional(),
        remarks: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.recordPayment(input);
    }),

  getPaymentsByStudent: protectedProcedure
    .input(z.number())
    .query(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin") {
        const student = await db.getStudentByUserId(ctx.user.id);
        if (!student || student.id !== input) {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
      }
      return await db.getPaymentsByStudent(input);
    }),
});

// ============================================================================
// NOTIFICATION ROUTER
// ============================================================================

const notificationRouter = router({
  create: adminProcedure
    .input(
      z.object({
        userId: z.number(),
        title: z.string(),
        message: z.string().optional(),
        type: z.enum(["attendance", "fee", "assignment", "grade", "general"]),
      })
    )
    .mutation(async ({ input }) => {
      return await db.createNotification(input);
    }),

  getByUser: protectedProcedure
    .input(z.number())
    .query(async ({ input, ctx }) => {
      if (ctx.user.role !== "admin" && ctx.user.id !== input) {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await db.getUserNotifications(input);
    }),

  markAsRead: protectedProcedure
    .input(z.number())
    .mutation(async ({ input }) => {
      return await db.markNotificationAsRead(input);
    }),
});

// ============================================================================
// MAIN APP ROUTER
// ============================================================================

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // SMS Feature Routers
  student: studentRouter,
  teacher: teacherRouter,
  course: courseRouter,
  subject: subjectRouter,
  attendance: attendanceRouter,
  assignment: assignmentRouter,
  exam: examRouter,
  result: resultRouter,
  timetable: timetableRouter,
  fee: feeRouter,
  notification: notificationRouter,
});

export type AppRouter = typeof appRouter;
