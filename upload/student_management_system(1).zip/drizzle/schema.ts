import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  boolean,
  datetime,
  unique,
  index,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extended with role-based access control for SMS.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }).unique(),
  phone: varchar("phone", { length: 20 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["admin", "teacher", "student", "parent", "user"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Course/Class table - represents a class or section in the institute
 */
export const courses = mysqlTable("courses", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  code: varchar("code", { length: 50 }).notNull().unique(),
  semester: int("semester").notNull(), // 1-8 for typical programs
  section: varchar("section", { length: 10 }), // A, B, C, etc.
  capacity: int("capacity").default(50),
  classTeacherId: int("classTeacherId").references(() => teachers.id),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Course = typeof courses.$inferSelect;
export type InsertCourse = typeof courses.$inferInsert;

/**
 * Subject table - represents a subject/course content
 */
export const subjects = mysqlTable("subjects", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  code: varchar("code", { length: 50 }).notNull().unique(),
  credits: int("credits").default(3),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Subject = typeof subjects.$inferSelect;
export type InsertSubject = typeof subjects.$inferInsert;

/**
 * Teacher table - extends user table with teacher-specific information
 */
export const teachers = mysqlTable("teachers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique().references(() => users.id),
  employeeId: varchar("employeeId", { length: 50 }).notNull().unique(),
  qualification: varchar("qualification", { length: 200 }),
  specialization: varchar("specialization", { length: 100 }),
  joiningDate: datetime("joiningDate"),
  department: varchar("department", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Teacher = typeof teachers.$inferSelect;
export type InsertTeacher = typeof teachers.$inferInsert;

/**
 * Student table - extends user table with student-specific information
 */
export const students = mysqlTable("students", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique().references(() => users.id),
  studentId: varchar("studentId", { length: 50 }).notNull().unique(),
  rollNumber: varchar("rollNumber", { length: 20 }).notNull().unique(),
  courseId: int("courseId").notNull().references(() => courses.id),
  dateOfBirth: datetime("dateOfBirth"),
  address: text("address"),
  city: varchar("city", { length: 50 }),
  state: varchar("state", { length: 50 }),
  pinCode: varchar("pinCode", { length: 10 }),
  parentId: int("parentId").references(() => parents.id),
  admissionDate: datetime("admissionDate"),
  status: mysqlEnum("status", ["active", "inactive", "graduated", "dropped"]).default("active"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  courseIdx: index("courseIdx").on(table.courseId),
  statusIdx: index("statusIdx").on(table.status),
}));

export type Student = typeof students.$inferSelect;
export type InsertStudent = typeof students.$inferInsert;

/**
 * Parent/Guardian table
 */
export const parents = mysqlTable("parents", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").references(() => users.id),
  name: varchar("name", { length: 100 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }).notNull(),
  relation: varchar("relation", { length: 50 }), // Father, Mother, Guardian
  occupation: varchar("occupation", { length: 100 }),
  address: text("address"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Parent = typeof parents.$inferSelect;
export type InsertParent = typeof parents.$inferInsert;

/**
 * Course-Subject mapping (Many-to-Many relationship)
 */
export const courseSubjects = mysqlTable("courseSubjects", {
  id: int("id").autoincrement().primaryKey(),
  courseId: int("courseId").notNull().references(() => courses.id),
  subjectId: int("subjectId").notNull().references(() => subjects.id),
  semester: int("semester").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  unique_course_subject: unique("unique_course_subject").on(table.courseId, table.subjectId),
}));

export type CourseSubject = typeof courseSubjects.$inferSelect;
export type InsertCourseSubject = typeof courseSubjects.$inferInsert;

/**
 * Teacher-Subject mapping (Many-to-Many relationship)
 */
export const teacherSubjects = mysqlTable("teacherSubjects", {
  id: int("id").autoincrement().primaryKey(),
  teacherId: int("teacherId").notNull().references(() => teachers.id),
  subjectId: int("subjectId").notNull().references(() => subjects.id),
  courseId: int("courseId").notNull().references(() => courses.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  unique_teacher_subject_course: unique("unique_teacher_subject_course").on(table.teacherId, table.subjectId, table.courseId),
}));

export type TeacherSubject = typeof teacherSubjects.$inferSelect;
export type InsertTeacherSubject = typeof teacherSubjects.$inferInsert;

/**
 * Attendance table - tracks daily attendance
 */
export const attendance = mysqlTable("attendance", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull().references(() => students.id),
  subjectId: int("subjectId").notNull().references(() => subjects.id),
  attendanceDate: datetime("attendanceDate").notNull(),
  status: mysqlEnum("status", ["present", "absent", "late", "leave"]).default("absent"),
  remarks: text("remarks"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  studentDateIdx: index("studentDateIdx").on(table.studentId, table.attendanceDate),
  subjectIdx: index("subjectIdx").on(table.subjectId),
}));

export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = typeof attendance.$inferInsert;

/**
 * Assignment table
 */
export const assignments = mysqlTable("assignments", {
  id: int("id").autoincrement().primaryKey(),
  subjectId: int("subjectId").notNull().references(() => subjects.id),
  teacherId: int("teacherId").notNull().references(() => teachers.id),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  dueDate: datetime("dueDate").notNull(),
  totalMarks: int("totalMarks").default(100),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  subjectIdx: index("subjectIdx").on(table.subjectId),
  teacherIdx: index("teacherIdx").on(table.teacherId),
}));

export type Assignment = typeof assignments.$inferSelect;
export type InsertAssignment = typeof assignments.$inferInsert;

/**
 * Assignment Submission table
 */
export const assignmentSubmissions = mysqlTable("assignmentSubmissions", {
  id: int("id").autoincrement().primaryKey(),
  assignmentId: int("assignmentId").notNull().references(() => assignments.id),
  studentId: int("studentId").notNull().references(() => students.id),
  submissionDate: datetime("submissionDate"),
  marks: int("marks"),
  feedback: text("feedback"),
  status: mysqlEnum("status", ["submitted", "pending", "late", "not_submitted"]).default("pending"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  assignmentIdx: index("assignmentIdx").on(table.assignmentId),
  studentIdx: index("studentIdx").on(table.studentId),
}));

export type AssignmentSubmission = typeof assignmentSubmissions.$inferSelect;
export type InsertAssignmentSubmission = typeof assignmentSubmissions.$inferInsert;

/**
 * Exam table
 */
export const exams = mysqlTable("exams", {
  id: int("id").autoincrement().primaryKey(),
  subjectId: int("subjectId").notNull().references(() => subjects.id),
  courseId: int("courseId").notNull().references(() => courses.id),
  examName: varchar("examName", { length: 100 }).notNull(),
  examType: mysqlEnum("examType", ["midterm", "final", "quiz", "practical"]).default("final"),
  examDate: datetime("examDate").notNull(),
  startTime: varchar("startTime", { length: 10 }),
  endTime: varchar("endTime", { length: 10 }),
  duration: int("duration"), // in minutes
  totalMarks: int("totalMarks").default(100),
  room: varchar("room", { length: 50 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  subjectIdx: index("subjectIdx").on(table.subjectId),
  courseIdx: index("courseIdx").on(table.courseId),
  examDateIdx: index("examDateIdx").on(table.examDate),
}));

export type Exam = typeof exams.$inferSelect;
export type InsertExam = typeof exams.$inferInsert;

/**
 * Result/Grade table
 */
export const results = mysqlTable("results", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull().references(() => students.id),
  subjectId: int("subjectId").notNull().references(() => subjects.id),
  examId: int("examId").references(() => exams.id),
  marksObtained: int("marksObtained"),
  totalMarks: int("totalMarks").default(100),
  percentage: decimal("percentage", { precision: 5, scale: 2 }),
  grade: varchar("grade", { length: 5 }), // A, B, C, D, F
  remarks: text("remarks"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  studentSubjectIdx: index("studentSubjectIdx").on(table.studentId, table.subjectId),
  examIdx: index("examIdx").on(table.examId),
}));

export type Result = typeof results.$inferSelect;
export type InsertResult = typeof results.$inferInsert;

/**
 * Timetable table
 */
export const timetables = mysqlTable("timetables", {
  id: int("id").autoincrement().primaryKey(),
  courseId: int("courseId").notNull().references(() => courses.id),
  subjectId: int("subjectId").notNull().references(() => subjects.id),
  teacherId: int("teacherId").notNull().references(() => teachers.id),
  dayOfWeek: mysqlEnum("dayOfWeek", ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]),
  startTime: varchar("startTime", { length: 10 }).notNull(),
  endTime: varchar("endTime", { length: 10 }).notNull(),
  room: varchar("room", { length: 50 }),
  semester: int("semester"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  courseIdx: index("courseIdx").on(table.courseId),
  dayTimeIdx: index("dayTimeIdx").on(table.dayOfWeek),
}));

export type Timetable = typeof timetables.$inferSelect;
export type InsertTimetable = typeof timetables.$inferInsert;

/**
 * Fee Structure table
 */
export const feeStructures = mysqlTable("feeStructures", {
  id: int("id").autoincrement().primaryKey(),
  courseId: int("courseId").notNull().references(() => courses.id),
  semester: int("semester").notNull(),
  feeType: varchar("feeType", { length: 100 }).notNull(), // Tuition, Hostel, Lab, etc.
  amount: int("amount").notNull(),
  dueDate: datetime("dueDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type FeeStructure = typeof feeStructures.$inferSelect;
export type InsertFeeStructure = typeof feeStructures.$inferInsert;

/**
 * Student Fee table - tracks fee for each student
 */
export const studentFees = mysqlTable("studentFees", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull().references(() => students.id),
  feeStructureId: int("feeStructureId").notNull().references(() => feeStructures.id),
  totalAmount: int("totalAmount").notNull(),
  paidAmount: int("paidAmount").default(0),
  dueDate: datetime("dueDate"),
  status: mysqlEnum("status", ["paid", "pending", "partial", "overdue"]).default("pending"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  studentIdx: index("studentIdx").on(table.studentId),
  statusIdx: index("statusIdx").on(table.status),
}));

export type StudentFee = typeof studentFees.$inferSelect;
export type InsertStudentFee = typeof studentFees.$inferInsert;

/**
 * Payment/Transaction table
 */
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  studentFeeId: int("studentFeeId").notNull().references(() => studentFees.id),
  amount: int("amount").notNull(),
  paymentDate: datetime("paymentDate").default(new Date()),
  paymentMethod: mysqlEnum("paymentMethod", ["cash", "cheque", "online", "bank_transfer"]).default("online"),
  transactionId: varchar("transactionId", { length: 100 }).unique(),
  remarks: text("remarks"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  studentFeeIdx: index("studentFeeIdx").on(table.studentFeeId),
  paymentDateIdx: index("paymentDateIdx").on(table.paymentDate),
}));

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

/**
 * Notification table
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id),
  title: varchar("title", { length: 200 }).notNull(),
  message: text("message"),
  type: mysqlEnum("type", ["attendance", "fee", "assignment", "grade", "general"]).default("general"),
  isRead: boolean("isRead").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIdx: index("userIdx").on(table.userId),
  isReadIdx: index("isReadIdx").on(table.isRead),
}));

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;
