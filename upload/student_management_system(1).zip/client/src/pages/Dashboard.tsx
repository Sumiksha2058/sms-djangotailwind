import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, BookOpen, Calendar, DollarSign, BarChart3, AlertCircle } from "lucide-react";
import { Link } from "wouter";
export default function Dashboard() {
  const { user } = useAuth();

  // Mock data - will be replaced with actual API calls
  const studentCount = 245;
  const teacherCount = 32;
  const courseCount = 18;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
            Student Management System
          </h1>
          <p className="text-slate-600 dark:text-slate-400 mt-2">
            Welcome back, {user?.name || "User"}
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Statistics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* Students Card */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Students</CardTitle>
              <Users className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{studentCount}</div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Active students in system
              </p>
            </CardContent>
          </Card>

          {/* Teachers Card */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Teachers</CardTitle>
              <BookOpen className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{teacherCount}</div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Faculty members
              </p>
            </CardContent>
          </Card>

          {/* Courses Card */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Courses</CardTitle>
              <Calendar className="h-4 w-4 text-purple-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{courseCount}</div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Active courses
              </p>
            </CardContent>
          </Card>

          {/* Revenue Card */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Fee Collection</CardTitle>
              <DollarSign className="h-4 w-4 text-amber-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹0</div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                This month
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>Manage core operations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <Link href="/students">
                  <Button variant="outline" className="w-full justify-start">
                    <Users className="h-4 w-4 mr-2" />
                    Students
                  </Button>
                </Link>
                <Link href="/teachers">
                  <Button variant="outline" className="w-full justify-start">
                    <BookOpen className="h-4 w-4 mr-2" />
                    Teachers
                  </Button>
                </Link>
                <Link href="/courses">
                  <Button variant="outline" className="w-full justify-start">
                    <Calendar className="h-4 w-4 mr-2" />
                    Courses
                  </Button>
                </Link>
                <Link href="/attendance">
                  <Button variant="outline" className="w-full justify-start">
                    <BarChart3 className="h-4 w-4 mr-2" />
                    Attendance
                  </Button>
                </Link>
                <Link href="/fees">
                  <Button variant="outline" className="w-full justify-start">
                    <DollarSign className="h-4 w-4 mr-2" />
                    Fees
                  </Button>
                </Link>
                <Link href="/timetable">
                  <Button variant="outline" className="w-full justify-start">
                    <Calendar className="h-4 w-4 mr-2" />
                    Timetable
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          {/* Alerts Card */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="h-4 w-4" />
                Alerts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="p-3 bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded">
                  <p className="text-sm font-medium text-yellow-900 dark:text-yellow-100">
                    Pending Fees
                  </p>
                  <p className="text-xs text-yellow-700 dark:text-yellow-300">
                    5 students have overdue fees
                  </p>
                </div>
                <div className="p-3 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded">
                  <p className="text-sm font-medium text-blue-900 dark:text-blue-100">
                    Low Attendance
                  </p>
                  <p className="text-xs text-blue-700 dark:text-blue-300">
                    3 students below 75% attendance
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>System Information</CardTitle>
            <CardDescription>Key metrics and statistics</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-slate-900 dark:text-white mb-3">
                  System Status
                </h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-400">Database</span>
                    <span className="text-green-600 dark:text-green-400 font-medium">Connected</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-400">API Server</span>
                    <span className="text-green-600 dark:text-green-400 font-medium">Running</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-400">Authentication</span>
                    <span className="text-green-600 dark:text-green-400 font-medium">Active</span>
                  </li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-slate-900 dark:text-white mb-3">
                  Quick Stats
                </h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-400">Average Attendance</span>
                    <span className="font-medium">82%</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-400">Fee Collection Rate</span>
                    <span className="font-medium">78%</span>
                  </li>
                  <li className="flex justify-between">
                    <span className="text-slate-600 dark:text-slate-400">Pass Rate</span>
                    <span className="font-medium">85%</span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
