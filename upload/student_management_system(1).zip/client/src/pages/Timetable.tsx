import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Calendar, Plus } from "lucide-react";
import { toast } from "sonner";

interface TimetableEntry {
  id: number;
  courseId: number;
  courseName: string;
  subjectName: string;
  teacherName: string;
  day: string;
  startTime: string;
  endTime: string;
  room: string;
}

const mockTimetable: TimetableEntry[] = [
  {
    id: 1,
    courseId: 1,
    courseName: "B.Tech - Semester 1",
    subjectName: "Mathematics",
    teacherName: "Dr. Sharma",
    day: "Monday",
    startTime: "09:00",
    endTime: "10:30",
    room: "A101",
  },
  {
    id: 2,
    courseId: 1,
    courseName: "B.Tech - Semester 1",
    subjectName: "Physics",
    teacherName: "Prof. Singh",
    day: "Monday",
    startTime: "10:45",
    endTime: "12:15",
    room: "A102",
  },
  {
    id: 3,
    courseId: 1,
    courseName: "B.Tech - Semester 1",
    subjectName: "Chemistry",
    teacherName: "Dr. Patel",
    day: "Tuesday",
    startTime: "09:00",
    endTime: "10:30",
    room: "A103",
  },
];

const days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export default function Timetable() {
  const { user } = useAuth();
  const [timetable, setTimetable] = useState<TimetableEntry[]>(mockTimetable);
  const [selectedCourse, setSelectedCourse] = useState("1");
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    day: "Monday",
    startTime: "09:00",
    endTime: "10:30",
    subjectName: "",
    teacherName: "",
    room: "",
  });

  const filteredTimetable = timetable.filter(
    (entry) => entry.courseId === parseInt(selectedCourse)
  );

  const handleAddEntry = () => {
    if (!formData.subjectName || !formData.teacherName || !formData.room) {
      toast.error("Please fill all required fields");
      return;
    }

    const newEntry: TimetableEntry = {
      id: timetable.length + 1,
      courseId: parseInt(selectedCourse),
      courseName: `B.Tech - Semester ${selectedCourse}`,
      ...formData,
    };

    setTimetable([...timetable, newEntry]);
    toast.success("Timetable entry added successfully");
    setFormData({
      day: "Monday",
      startTime: "09:00",
      endTime: "10:30",
      subjectName: "",
      teacherName: "",
      room: "",
    });
    setIsOpen(false);
  };

  // Group timetable by day
  const timetableByDay = days.reduce(
    (acc, day) => {
      acc[day] = filteredTimetable.filter((entry) => entry.day === day);
      return acc;
    },
    {} as Record<string, TimetableEntry[]>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Calendar className="h-8 w-8 text-indigo-600 dark:text-indigo-400" />
              <div>
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
                  Timetable Management
                </h1>
                <p className="text-slate-600 dark:text-slate-400 mt-1">
                  Manage class schedules and exam timetables
                </p>
              </div>
            </div>
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  Add Entry
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Timetable Entry</DialogTitle>
                  <DialogDescription>
                    Add a new class schedule to the timetable
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Day *</label>
                    <Select value={formData.day} onValueChange={(value) =>
                      setFormData({ ...formData, day: value })
                    }>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {days.map((day) => (
                          <SelectItem key={day} value={day}>
                            {day}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-sm font-medium">Start Time *</label>
                      <Input
                        type="time"
                        value={formData.startTime}
                        onChange={(e) =>
                          setFormData({ ...formData, startTime: e.target.value })
                        }
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">End Time *</label>
                      <Input
                        type="time"
                        value={formData.endTime}
                        onChange={(e) =>
                          setFormData({ ...formData, endTime: e.target.value })
                        }
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Subject *</label>
                    <Input
                      placeholder="e.g., Mathematics"
                      value={formData.subjectName}
                      onChange={(e) =>
                        setFormData({ ...formData, subjectName: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Teacher *</label>
                    <Input
                      placeholder="e.g., Dr. Sharma"
                      value={formData.teacherName}
                      onChange={(e) =>
                        setFormData({ ...formData, teacherName: e.target.value })
                      }
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Room *</label>
                    <Input
                      placeholder="e.g., A101"
                      value={formData.room}
                      onChange={(e) =>
                        setFormData({ ...formData, room: e.target.value })
                      }
                    />
                  </div>
                  <div className="flex gap-2 pt-4">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setIsOpen(false);
                        setFormData({
                          day: "Monday",
                          startTime: "09:00",
                          endTime: "10:30",
                          subjectName: "",
                          teacherName: "",
                          room: "",
                        });
                      }}
                    >
                      Cancel
                    </Button>
                    <Button onClick={handleAddEntry}>Add Entry</Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Course Selector */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex gap-4 items-end">
              <div className="flex-1">
                <label className="text-sm font-medium block mb-2">
                  Select Course
                </label>
                <Select value={selectedCourse} onValueChange={setSelectedCourse}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">B.Tech - Semester 1</SelectItem>
                    <SelectItem value="2">B.Tech - Semester 2</SelectItem>
                    <SelectItem value="3">B.Tech - Semester 3</SelectItem>
                    <SelectItem value="4">B.Tech - Semester 4</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Timetable Grid */}
        <div className="space-y-6">
          {days.map((day) => (
            <Card key={day}>
              <CardHeader>
                <CardTitle>{day}</CardTitle>
              </CardHeader>
              <CardContent>
                {timetableByDay[day].length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-slate-200 dark:border-slate-800">
                          <th className="text-left py-2 px-4 font-semibold text-slate-900 dark:text-white">
                            Time
                          </th>
                          <th className="text-left py-2 px-4 font-semibold text-slate-900 dark:text-white">
                            Subject
                          </th>
                          <th className="text-left py-2 px-4 font-semibold text-slate-900 dark:text-white">
                            Teacher
                          </th>
                          <th className="text-left py-2 px-4 font-semibold text-slate-900 dark:text-white">
                            Room
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {timetableByDay[day].map((entry) => (
                          <tr
                            key={entry.id}
                            className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-900"
                          >
                            <td className="py-3 px-4 font-medium text-slate-900 dark:text-white">
                              {entry.startTime} - {entry.endTime}
                            </td>
                            <td className="py-3 px-4 text-slate-900 dark:text-white">
                              {entry.subjectName}
                            </td>
                            <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                              {entry.teacherName}
                            </td>
                            <td className="py-3 px-4">
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-200">
                                {entry.room}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-slate-500 dark:text-slate-400 text-center py-4">
                    No classes scheduled for {day}
                  </p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
