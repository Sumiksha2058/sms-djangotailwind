import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart3, Calendar } from "lucide-react";
import { toast } from "sonner";

interface AttendanceRecord {
  id: number;
  studentId: string;
  studentName: string;
  date: string;
  status: "present" | "absent" | "late" | "leave";
}

const mockAttendance: AttendanceRecord[] = [
  {
    id: 1,
    studentId: "STU001",
    studentName: "Raj Kumar",
    date: "2024-12-03",
    status: "present",
  },
  {
    id: 2,
    studentId: "STU002",
    studentName: "Priya Singh",
    date: "2024-12-03",
    status: "present",
  },
  {
    id: 3,
    studentId: "STU003",
    studentName: "Amit Patel",
    date: "2024-12-03",
    status: "absent",
  },
];

export default function Attendance() {
  const { user } = useAuth();
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(mockAttendance);
  const [selectedDate, setSelectedDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [selectedStatus, setSelectedStatus] = useState<string>("all");

  const filteredAttendance = attendance.filter((record) => {
    const dateMatch = record.date === selectedDate;
    const statusMatch =
      selectedStatus === "all" || record.status === selectedStatus;
    return dateMatch && statusMatch;
  });

  const attendanceStats = {
    present: filteredAttendance.filter((r) => r.status === "present").length,
    absent: filteredAttendance.filter((r) => r.status === "absent").length,
    late: filteredAttendance.filter((r) => r.status === "late").length,
    leave: filteredAttendance.filter((r) => r.status === "leave").length,
  };

  const handleMarkAttendance = (recordId: number, status: string) => {
    setAttendance(
      attendance.map((record) =>
        record.id === recordId
          ? { ...record, status: status as any }
          : record
      )
    );
    toast.success("Attendance updated");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center gap-3">
            <BarChart3 className="h-8 w-8 text-purple-600 dark:text-purple-400" />
            <div>
              <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
                Attendance Management
              </h1>
              <p className="text-slate-600 dark:text-slate-400 mt-1">
                Mark and track student attendance
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-600 dark:text-green-400">
                  {attendanceStats.present}
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                  Present
                </p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-red-600 dark:text-red-400">
                  {attendanceStats.absent}
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                  Absent
                </p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-yellow-600 dark:text-yellow-400">
                  {attendanceStats.late}
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                  Late
                </p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">
                  {attendanceStats.leave}
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
                  Leave
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <label className="text-sm font-medium block mb-2">Date</label>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-slate-400" />
                  <Input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                  />
                </div>
              </div>
              <div className="flex-1">
                <label className="text-sm font-medium block mb-2">
                  Filter by Status
                </label>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="present">Present</SelectItem>
                    <SelectItem value="absent">Absent</SelectItem>
                    <SelectItem value="late">Late</SelectItem>
                    <SelectItem value="leave">Leave</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Attendance Table */}
        <Card>
          <CardHeader>
            <CardTitle>Attendance Records</CardTitle>
            <CardDescription>
              Date: {selectedDate} | Total: {filteredAttendance.length} records
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800">
                    <th className="text-left py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      Student ID
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      Name
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      Status
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      Action
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredAttendance.map((record) => (
                    <tr
                      key={record.id}
                      className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors"
                    >
                      <td className="py-3 px-4 text-slate-900 dark:text-white font-medium">
                        {record.studentId}
                      </td>
                      <td className="py-3 px-4 text-slate-900 dark:text-white">
                        {record.studentName}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            record.status === "present"
                              ? "bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200"
                              : record.status === "absent"
                              ? "bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200"
                              : record.status === "late"
                              ? "bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200"
                              : "bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200"
                          }`}
                        >
                          {record.status}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <Select
                          value={record.status}
                          onValueChange={(value) =>
                            handleMarkAttendance(record.id, value)
                          }
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="present">Present</SelectItem>
                            <SelectItem value="absent">Absent</SelectItem>
                            <SelectItem value="late">Late</SelectItem>
                            <SelectItem value="leave">Leave</SelectItem>
                          </SelectContent>
                        </Select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
