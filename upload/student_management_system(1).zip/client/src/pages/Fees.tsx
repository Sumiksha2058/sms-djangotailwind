import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { DollarSign, Plus, Download } from "lucide-react";
import { toast } from "sonner";

interface FeeRecord {
  id: number;
  studentId: string;
  studentName: string;
  totalAmount: number;
  paidAmount: number;
  dueDate: string;
  status: "paid" | "pending" | "partial" | "overdue";
}

const mockFees: FeeRecord[] = [
  {
    id: 1,
    studentId: "STU001",
    studentName: "Raj Kumar",
    totalAmount: 50000,
    paidAmount: 50000,
    dueDate: "2024-11-30",
    status: "paid",
  },
  {
    id: 2,
    studentId: "STU002",
    studentName: "Priya Singh",
    totalAmount: 50000,
    paidAmount: 25000,
    dueDate: "2024-12-15",
    status: "partial",
  },
  {
    id: 3,
    studentId: "STU003",
    studentName: "Amit Patel",
    totalAmount: 50000,
    paidAmount: 0,
    dueDate: "2024-11-30",
    status: "overdue",
  },
];

export default function Fees() {
  const { user } = useAuth();
  const [fees, setFees] = useState<FeeRecord[]>(mockFees);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [isOpen, setIsOpen] = useState(false);
  const [paymentData, setPaymentData] = useState({
    studentId: "",
    amount: "",
    paymentMethod: "online",
  });

  const filteredFees = fees.filter((fee) => {
    const searchMatch =
      fee.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      fee.studentName.toLowerCase().includes(searchQuery.toLowerCase());
    const statusMatch = selectedStatus === "all" || fee.status === selectedStatus;
    return searchMatch && statusMatch;
  });

  const totalAmount = filteredFees.reduce((sum, fee) => sum + fee.totalAmount, 0);
  const totalPaid = filteredFees.reduce((sum, fee) => sum + fee.paidAmount, 0);
  const totalPending = totalAmount - totalPaid;

  const handleRecordPayment = () => {
    if (!paymentData.studentId || !paymentData.amount) {
      toast.error("Please fill all required fields");
      return;
    }

    const feeIndex = fees.findIndex((f) => f.studentId === paymentData.studentId);
    if (feeIndex === -1) {
      toast.error("Student not found");
      return;
    }

    const updatedFees = [...fees];
    const amount = parseFloat(paymentData.amount);
    updatedFees[feeIndex].paidAmount += amount;

    if (updatedFees[feeIndex].paidAmount >= updatedFees[feeIndex].totalAmount) {
      updatedFees[feeIndex].status = "paid";
    } else if (updatedFees[feeIndex].paidAmount > 0) {
      updatedFees[feeIndex].status = "partial";
    }

    setFees(updatedFees);
    toast.success("Payment recorded successfully");
    setPaymentData({ studentId: "", amount: "", paymentMethod: "online" });
    setIsOpen(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <DollarSign className="h-8 w-8 text-amber-600 dark:text-amber-400" />
              <div>
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
                  Fee Management
                </h1>
                <p className="text-slate-600 dark:text-slate-400 mt-1">
                  Track and manage student fees and payments
                </p>
              </div>
            </div>
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  Record Payment
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Record Payment</DialogTitle>
                  <DialogDescription>
                    Add a new payment for a student
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Student ID *</label>
                    <Input
                      placeholder="e.g., STU001"
                      value={paymentData.studentId}
                      onChange={(e) =>
                        setPaymentData({
                          ...paymentData,
                          studentId: e.target.value,
                        })
                      }
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Amount *</label>
                    <Input
                      type="number"
                      placeholder="0.00"
                      value={paymentData.amount}
                      onChange={(e) =>
                        setPaymentData({
                          ...paymentData,
                          amount: e.target.value,
                        })
                      }
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">
                      Payment Method
                    </label>
                    <Select
                      value={paymentData.paymentMethod}
                      onValueChange={(value) =>
                        setPaymentData({
                          ...paymentData,
                          paymentMethod: value,
                        })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="online">Online</SelectItem>
                        <SelectItem value="cash">Cash</SelectItem>
                        <SelectItem value="cheque">Cheque</SelectItem>
                        <SelectItem value="bank_transfer">
                          Bank Transfer
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex gap-2 pt-4">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setIsOpen(false);
                        setPaymentData({
                          studentId: "",
                          amount: "",
                          paymentMethod: "online",
                        });
                      }}
                    >
                      Cancel
                    </Button>
                    <Button onClick={handleRecordPayment}>
                      Record Payment
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Amount</CardTitle>
              <DollarSign className="h-4 w-4 text-slate-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{totalAmount.toLocaleString()}</div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                All students
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Paid</CardTitle>
              <DollarSign className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{totalPaid.toLocaleString()}</div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                {totalAmount > 0 ? Math.round((totalPaid / totalAmount) * 100) : 0}% collected
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
              <DollarSign className="h-4 w-4 text-red-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">₹{totalPending.toLocaleString()}</div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Outstanding
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <label className="text-sm font-medium block mb-2">Search</label>
                <Input
                  placeholder="Search by student ID or name..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="flex-1">
                <label className="text-sm font-medium block mb-2">
                  Filter by Status
                </label>
                <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="paid">Paid</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="partial">Partial</SelectItem>
                    <SelectItem value="overdue">Overdue</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-end">
                <Button variant="outline" className="gap-2">
                  <Download className="h-4 w-4" />
                  Export
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Fees Table */}
        <Card>
          <CardHeader>
            <CardTitle>Fee Records</CardTitle>
            <CardDescription>
              Total: {filteredFees.length} records
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800">
                    <th className="text-left py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      Student ID
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      Name
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      Total
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      Paid
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      Pending
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {filteredFees.map((fee) => (
                    <tr
                      key={fee.id}
                      className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors"
                    >
                      <td className="py-3 px-4 text-slate-900 dark:text-white font-medium">
                        {fee.studentId}
                      </td>
                      <td className="py-3 px-4 text-slate-900 dark:text-white">
                        {fee.studentName}
                      </td>
                      <td className="py-3 px-4 text-slate-900 dark:text-white">
                        ₹{fee.totalAmount.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-green-600 dark:text-green-400 font-medium">
                        ₹{fee.paidAmount.toLocaleString()}
                      </td>
                      <td className="py-3 px-4 text-red-600 dark:text-red-400 font-medium">
                        ₹{(fee.totalAmount - fee.paidAmount).toLocaleString()}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            fee.status === "paid"
                              ? "bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200"
                              : fee.status === "pending"
                              ? "bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200"
                              : fee.status === "partial"
                              ? "bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200"
                              : "bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200"
                          }`}
                        >
                          {fee.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
