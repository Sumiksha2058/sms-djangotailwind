import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart3, Download, TrendingUp } from "lucide-react";

interface ReportData {
  name: string;
  attendance: number;
  performance: number;
  fees: number;
}

const mockReportData: ReportData[] = [
  { name: "Raj Kumar", attendance: 92, performance: 85, fees: 100 },
  { name: "Priya Singh", attendance: 88, performance: 78, fees: 50 },
  { name: "Amit Patel", attendance: 75, performance: 82, fees: 0 },
  { name: "Neha Gupta", attendance: 95, performance: 90, fees: 100 },
  { name: "Rohan Verma", attendance: 70, performance: 72, fees: 75 },
];

export default function Reports() {
  const { user } = useAuth();
  const [reportType, setReportType] = useState("attendance");
  const [sortBy, setSortBy] = useState("name");

  // Sorting algorithms
  const getSortedData = () => {
    const dataCopy = [...mockReportData];

    if (sortBy === "name") {
      // Merge sort for alphabetical sorting
      return mergeSort(dataCopy, (a, b) => a.name.localeCompare(b.name));
    } else if (sortBy === "attendance") {
      // Quick sort for attendance (descending)
      return quickSort(dataCopy, (a, b) => b.attendance - a.attendance);
    } else if (sortBy === "performance") {
      // Heap sort for top performers
      return heapSort(dataCopy, (a, b) => b.performance - a.performance);
    } else if (sortBy === "fees") {
      return quickSort(dataCopy, (a, b) => b.fees - a.fees);
    }

    return dataCopy;
  };

  // Merge Sort Algorithm
  const mergeSort = (arr: ReportData[], compareFn: (a: ReportData, b: ReportData) => number): ReportData[] => {
    if (arr.length <= 1) return arr;

    const mid = Math.floor(arr.length / 2);
    const left = mergeSort(arr.slice(0, mid), compareFn);
    const right = mergeSort(arr.slice(mid), compareFn);

    return merge(left, right, compareFn);
  };

  const merge = (left: ReportData[], right: ReportData[], compareFn: (a: ReportData, b: ReportData) => number): ReportData[] => {
    const result: ReportData[] = [];
    let i = 0,
      j = 0;

    while (i < left.length && j < right.length) {
      if (compareFn(left[i], right[j]) <= 0) {
        result.push(left[i++]);
      } else {
        result.push(right[j++]);
      }
    }

    return result.concat(left.slice(i)).concat(right.slice(j));
  };

  // Quick Sort Algorithm
  const quickSort = (arr: ReportData[], compareFn: (a: ReportData, b: ReportData) => number): ReportData[] => {
    if (arr.length <= 1) return arr;

    const pivot = arr[0];
    const left = arr.slice(1).filter((x) => compareFn(x, pivot) <= 0);
    const right = arr.slice(1).filter((x) => compareFn(x, pivot) > 0);

    return [...quickSort(left, compareFn), pivot, ...quickSort(right, compareFn)];
  };

  // Heap Sort Algorithm
  const heapSort = (arr: ReportData[], compareFn: (a: ReportData, b: ReportData) => number): ReportData[] => {
    const result = [...arr];
    const n = result.length;

    for (let i = Math.floor(n / 2) - 1; i >= 0; i--) {
      heapify(result, n, i, compareFn);
    }

    for (let i = n - 1; i > 0; i--) {
      [result[0], result[i]] = [result[i], result[0]];
      heapify(result, i, 0, compareFn);
    }

    return result;
  };

  const heapify = (arr: ReportData[], n: number, i: number, compareFn: (a: ReportData, b: ReportData) => number) => {
    let largest = i;
    const left = 2 * i + 1;
    const right = 2 * i + 2;

    if (left < n && compareFn(arr[left], arr[largest]) > 0) {
      largest = left;
    }
    if (right < n && compareFn(arr[right], arr[largest]) > 0) {
      largest = right;
    }

    if (largest !== i) {
      [arr[i], arr[largest]] = [arr[largest], arr[i]];
      heapify(arr, n, largest, compareFn);
    }
  };

  // Binary search for quick student lookup
  const binarySearch = (arr: ReportData[], target: string): ReportData | null => {
    let left = 0,
      right = arr.length - 1;

    while (left <= right) {
      const mid = Math.floor((left + right) / 2);
      const comparison = arr[mid].name.localeCompare(target);

      if (comparison === 0) return arr[mid];
      if (comparison < 0) left = mid + 1;
      else right = mid - 1;
    }

    return null;
  };

  const sortedData = getSortedData();

  // Calculate statistics
  const avgAttendance = Math.round(
    mockReportData.reduce((sum, d) => sum + d.attendance, 0) / mockReportData.length
  );
  const avgPerformance = Math.round(
    mockReportData.reduce((sum, d) => sum + d.performance, 0) / mockReportData.length
  );
  const feeCollection = Math.round(
    (mockReportData.reduce((sum, d) => sum + d.fees, 0) / (mockReportData.length * 100)) * 100
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <BarChart3 className="h-8 w-8 text-cyan-600 dark:text-cyan-400" />
              <div>
                <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
                  Reports & Analytics
                </h1>
                <p className="text-slate-600 dark:text-slate-400 mt-1">
                  Advanced reporting with sorting algorithms
                </p>
              </div>
            </div>
            <Button className="gap-2">
              <Download className="h-4 w-4" />
              Export Report
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg Attendance</CardTitle>
              <TrendingUp className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{avgAttendance}%</div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                All students
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg Performance</CardTitle>
              <TrendingUp className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{avgPerformance}%</div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Academic score
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Fee Collection</CardTitle>
              <TrendingUp className="h-4 w-4 text-amber-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{feeCollection}%</div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Collection rate
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Report Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <label className="text-sm font-medium block mb-2">Report Type</label>
                <Select value={reportType} onValueChange={setReportType}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="attendance">Attendance Report</SelectItem>
                    <SelectItem value="performance">Performance Report</SelectItem>
                    <SelectItem value="fees">Fee Report</SelectItem>
                    <SelectItem value="combined">Combined Report</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1">
                <label className="text-sm font-medium block mb-2">Sort By</label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="name">Name (Merge Sort)</SelectItem>
                    <SelectItem value="attendance">Attendance (Quick Sort)</SelectItem>
                    <SelectItem value="performance">Performance (Heap Sort)</SelectItem>
                    <SelectItem value="fees">Fees (Quick Sort)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Report Table */}
        <Card>
          <CardHeader>
            <CardTitle>Student Report</CardTitle>
            <CardDescription>
              Sorted by {sortBy} | Total: {sortedData.length} students
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800">
                    <th className="text-left py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      Student Name
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      Attendance
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      Performance
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      Fee Status
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-slate-900 dark:text-white">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {sortedData.map((data, index) => {
                    const attendanceStatus =
                      data.attendance >= 75 ? "good" : "warning";
                    const performanceStatus =
                      data.performance >= 80 ? "excellent" : "good";
                    const feeStatus = data.fees === 100 ? "paid" : "pending";

                    return (
                      <tr
                        key={index}
                        className="border-b border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors"
                      >
                        <td className="py-3 px-4 text-slate-900 dark:text-white font-medium">
                          {data.name}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <div className="w-32 bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                              <div
                                className={`h-2 rounded-full ${
                                  attendanceStatus === "good"
                                    ? "bg-green-500"
                                    : "bg-yellow-500"
                                }`}
                                style={{ width: `${data.attendance}%` }}
                              ></div>
                            </div>
                            <span className="text-sm font-medium">
                              {data.attendance}%
                            </span>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <div className="w-32 bg-slate-200 dark:bg-slate-700 rounded-full h-2">
                              <div
                                className={`h-2 rounded-full ${
                                  performanceStatus === "excellent"
                                    ? "bg-blue-500"
                                    : "bg-cyan-500"
                                }`}
                                style={{ width: `${data.performance}%` }}
                              ></div>
                            </div>
                            <span className="text-sm font-medium">
                              {data.performance}%
                            </span>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              feeStatus === "paid"
                                ? "bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200"
                                : "bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200"
                            }`}
                          >
                            {feeStatus === "paid" ? "Paid" : "Pending"}
                          </span>
                        </td>
                        <td className="py-3 px-4">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200">
                            Active
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Algorithm Info */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Sorting Algorithms Used</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-lg">
                <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
                  Merge Sort
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Used for alphabetical sorting (Name). Time Complexity: O(n log n)
                </p>
              </div>
              <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-lg">
                <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
                  Quick Sort
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Used for numeric sorting (Attendance, Fees). Time Complexity: O(n log n)
                </p>
              </div>
              <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-lg">
                <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
                  Heap Sort
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Used for finding top performers. Time Complexity: O(n log n)
                </p>
              </div>
              <div className="p-4 bg-slate-50 dark:bg-slate-900 rounded-lg">
                <h3 className="font-semibold text-slate-900 dark:text-white mb-2">
                  Binary Search
                </h3>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  Available for quick student lookup. Time Complexity: O(log n)
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
